# Target Demo Android + Shizuku

A minimal Android Studio project for Android 11+ devices, including Redmi Turbo 5 Pro / Android 16.

## What is included
- A Shizuku status check (service connected / app permission granted).
- A button to request this app's Shizuku permission using the official Shizuku API.
- A simulated moving target and smooth crosshair in this app's own test scene.
- A simulated key state (`HELD` / `RELEASED`); it releases when the simulated target is hidden.

## Safety and limits
The Shizuku integration in this version only checks connectivity and requests permission. It does **not** run privileged commands or control other apps. The target and key state are simulations inside this app; no screen capture, game automation, real key events, or auto-aim is implemented. Shizuku permission does not automatically grant root access, and ADB privileges are limited by Android.

## Build
1. Open the project folder in Android Studio or another Gradle Android build environment.
2. Allow Gradle sync and network access so Gradle can download the Shizuku API dependencies.
3. Choose **Build > Build APK(s)**.
4. Install the debug APK, open Shizuku, make sure its service is running, open Target Demo, then tap **檢查狀態** and **申請 Shizuku 授權**.

On an unrooted device, Shizuku usually needs to be started again after a reboot. See the official setup guide: https://shizuku.rikka.app/guide/setup/

Official API documentation: https://github.com/RikkaApps/Shizuku-API

## Automatic APK build with GitHub Actions

This project includes `.github/workflows/build-apk.yml`. After you upload the project to a GitHub repository and push it to `main` or `master`, GitHub Actions automatically builds a debug APK. You can also run it manually from the repository's **Actions** tab using **Build Android APK** → **Run workflow**.

When the workflow succeeds, open the run and download the `TargetDemo-debug-apk` artifact. GitHub provides it as a ZIP containing the APK. This is a debug build for testing, not a Play Store release-signed APK.
