plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

dependencies {
    // Shizuku API for requesting the user-granted Shizuku permission.
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
android {
    namespace = "com.example.targetdemo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.targetdemo"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
