package com.example.targetdemo

import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var demoView: DemoView
    private val permissionRequestCode = 7301

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { refreshShizukuStatus() }
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread { refreshShizukuStatus() }
    }
    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == permissionRequestCode) {
            runOnUiThread {
                refreshShizukuStatus()
                statusText.text = if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    "Shizuku 授權：已允許（測試功能仍只作用於本 App）"
                } else {
                    "Shizuku 授權：未允許；可按「申請 Shizuku 授權」再試"
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
            setBackgroundColor(Color.rgb(18, 24, 33))
        }
        val title = TextView(this).apply {
            text = "Target Demo + Shizuku"
            textSize = 22f
            setTextColor(Color.WHITE)
        }
        statusText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(8))
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val checkButton = Button(this).apply {
            text = "檢查狀態"
            setOnClickListener { refreshShizukuStatus() }
        }
        val requestButton = Button(this).apply {
            text = "申請 Shizuku 授權"
            setOnClickListener { requestShizukuPermission() }
        }
        buttons.addView(checkButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons.addView(requestButton, LinearLayout.LayoutParams(0, dp(48), 1.4f).apply {
            marginStart = dp(8)
        })

        demoView = DemoView()
        root.addView(title)
        root.addView(statusText)
        root.addView(buttons)
        root.addView(demoView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = dp(8) })
        setContentView(root)

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        refreshShizukuStatus()
    }

    private fun requestShizukuPermission() {
        if (!Shizuku.pingBinder()) {
            statusText.text = "Shizuku 服務未連線。請先打開 Shizuku，啟動服務，再按檢查狀態。"
            return
        }
        if (Shizuku.isPreV11()) {
            statusText.text = "目前 Shizuku API 不支援此舊版本。"
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            statusText.text = "Shizuku 授權：已允許（測試功能仍只作用於本 App）"
            return
        }
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            statusText.text = "你之前拒絕過授權。請到 Shizuku 的應用程式管理頁確認權限，再回來重試。"
            return
        }
        Shizuku.requestPermission(permissionRequestCode)
    }

    private fun refreshShizukuStatus() {
        if (!::statusText.isInitialized) return
        statusText.text = when {
            !Shizuku.pingBinder() -> "Shizuku 服務：未連線。請在 Shizuku App 啟動服務。"
            Shizuku.isPreV11() -> "Shizuku API：版本不支援。"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                "Shizuku 服務：已連線｜App 授權：已允許"
            else -> "Shizuku 服務：已連線｜App 授權：尚未授權，按下方按鈕申請"
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        super.onDestroy()
    }

    private inner class DemoView : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val handler = Handler(Looper.getMainLooper())
        private var t = 0f
        private var targetVisible = true
        private var crossX = 0f
        private var crossY = 0f
        private var holding = false
        private val tick = object : Runnable {
            override fun run() {
                t += 0.035f
                targetVisible = ((t.toInt() % 18) < 15)
                val tx = width * (0.5f + 0.28f * kotlin.math.sin(t))
                val ty = height * (0.43f + 0.18f * kotlin.math.cos(t * 0.7f))
                if (crossX == 0f && crossY == 0f) {
                    crossX = width / 2f
                    crossY = height / 2f
                }
                if (targetVisible) {
                    crossX += (tx - crossX) * 0.12f
                    crossY += (ty - crossY) * 0.12f
                    holding = hypot(tx - crossX, ty - crossY) < 38f
                } else {
                    holding = false // Always release simulated key when target disappears.
                }
                invalidate()
                handler.postDelayed(this, 16L)
            }
        }

        init {
            isFocusable = true
            handler.post(tick)
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            c.drawColor(Color.rgb(18, 24, 33))
            p.style = Paint.Style.FILL
            p.color = Color.rgb(35, 48, 64)
            c.drawRoundRect(RectF(width * 0.03f, height * 0.03f, width * 0.97f, height * 0.91f), 24f, 24f, p)
            val tx = width * (0.5f + 0.28f * kotlin.math.sin(t))
            val ty = height * (0.43f + 0.18f * kotlin.math.cos(t * 0.7f))
            if (targetVisible) {
                p.color = Color.rgb(255, 175, 75)
                c.drawCircle(tx, ty, 24f, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 3f
                p.color = Color.WHITE
                c.drawCircle(tx, ty, 32f, p)
                p.style = Paint.Style.FILL
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f
            p.color = if (holding) Color.rgb(70, 230, 135) else Color.rgb(70, 210, 255)
            c.drawCircle(crossX, crossY, 22f, p)
            c.drawLine(crossX - 34, crossY, crossX - 10, crossY, p)
            c.drawLine(crossX + 10, crossY, crossX + 34, crossY, p)
            c.drawLine(crossX, crossY - 34, crossX, crossY - 10, p)
            c.drawLine(crossX, crossY + 10, crossX, crossY + 34, p)
            p.style = Paint.Style.FILL
            p.textSize = 18f
            p.color = Color.WHITE
            c.drawText("Demo target: " + if (targetVisible) "VISIBLE" else "HIDDEN", width * 0.07f, height * 0.95f, p)
            p.color = if (holding) Color.rgb(70, 230, 135) else Color.rgb(255, 130, 130)
            c.drawText("Simulated key: " + if (holding) "HELD" else "RELEASED", width * 0.07f, height * 0.99f, p)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_UP) {
                crossX = width / 2f
                crossY = height / 2f
                invalidate()
            }
            return true
        }

        override fun onDetachedFromWindow() {
            handler.removeCallbacks(tick)
            super.onDetachedFromWindow()
        }
    }
}
